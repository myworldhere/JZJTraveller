//
//  JZJForthViewController.m
//  UniversalTemplate
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "JZJForthViewController.h"

@interface JZJForthViewController ()

@end

@implementation JZJForthViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}
@end
