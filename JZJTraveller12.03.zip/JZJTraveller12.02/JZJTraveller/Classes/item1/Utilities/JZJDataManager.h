//
//  JZJDataManager.h
//  JZJTraveller
//
//  Created by tarena on 15/12/1.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
@class JZJBooks;
@interface JZJDataManager : NSObject
+(NSArray*)getBooksFromData:(id)data;
@end
