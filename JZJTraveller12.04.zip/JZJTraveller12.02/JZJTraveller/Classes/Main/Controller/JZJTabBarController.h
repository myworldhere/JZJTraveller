//
//  JZJTabBarController.h
//  UniversalTemplate
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZJTabBarController : UITabBarController

@end
