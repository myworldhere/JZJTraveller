//
//  JZJTicketInformation.m
//  JZJTraveller
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "JZJTicketInformation.h"

@implementation JZJTicketInformation

@end
