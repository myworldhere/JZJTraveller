//
//  JZJTicketInformation.h
//  JZJTraveller
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZJTicketInformation : NSObject
@property (nonatomic,strong) NSString* price;
@property (nonatomic,strong) NSString* open_time;
@property (nonatomic,strong) NSArray* attention;
@end
