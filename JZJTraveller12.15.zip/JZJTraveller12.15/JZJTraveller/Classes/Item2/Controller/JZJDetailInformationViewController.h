//
//  JZJDetailInformationViewController.h
//  JZJTraveller
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZJDetailInformationViewController : UIViewController
@property (nonatomic,strong) NSString* urlString;
@end
