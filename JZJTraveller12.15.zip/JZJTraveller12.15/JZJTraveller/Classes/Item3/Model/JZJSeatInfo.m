//
//  JZJSeatInfo.m
//  JZJTraveller
//
//  Created by tarena on 15/12/15.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "JZJSeatInfo.h"

@implementation JZJSeatInfo

@end
