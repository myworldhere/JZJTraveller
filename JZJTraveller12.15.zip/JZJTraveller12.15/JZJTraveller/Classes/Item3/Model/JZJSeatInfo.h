//
//  JZJSeatInfo.h
//  JZJTraveller
//
//  Created by tarena on 15/12/15.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZJSeatInfo : NSObject
@property (nonatomic,strong) NSString* seat;
@property (nonatomic,strong) NSString* seatPrice;
@property (nonatomic,strong) NSString* remainNum;
@end
